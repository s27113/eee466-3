package generated;

public class Countdown {

	public static void countdown (int from, String message){
		int current = from;
		while (0 < current){
			current = displayAndDecrementCount(current);
		}
		System.out.print(message + "\n");
	}

	public static int displayAndDecrementCount (int c){
		System.out.print(c);
		System.out.print("\n");
		c = c - 1;
		if (c == 3) {
		System.out.print("Get ready!\n");
		} 
		return c;
	}

	public static void main(String[] args){
		String announce = "Liftoff";
		countdown(10, announce);
	}

}
