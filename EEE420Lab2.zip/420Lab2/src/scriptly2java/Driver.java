package scriptly2java;

import java.io.IOException;

import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import scriptlygrammar.ScriptlyLexer;
import scriptlygrammar.ScriptlyParser;
import util420.IOUtils;

/**
 * Utility functions for translating Scriptly files to Java.
 * 
 * @author EEE/GEF420 instructors
 * 
 * @version 8 July 2016
 *
 */

public class Driver {
	
	public static String translateFile(String sourceFilePath) throws Exception {
		ScriptlyParser parser = fileParser(sourceFilePath);
		ParseTree tree = parser.script();
		ParseTreeWalker walker = new ParseTreeWalker();
		Translator translator = new Translator();
		walker.walk(translator, tree);
		String javaTranslation = translator.getJava(tree);
		String classname = IOUtils.baseName(sourceFilePath);
		javaTranslation = javaTranslation.replaceAll("className", classname);
		return javaTranslation;
	}

	public static ScriptlyParser fileParser(String sourceFilePath) {
		ANTLRFileStream input = null;
		try {
			input = new ANTLRFileStream(sourceFilePath);
		} catch (IOException e) {
			System.err.println("could not open file at " + sourceFilePath);
			System.exit(0);
		}
		ScriptlyLexer lexer = new ScriptlyLexer(input);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		ScriptlyParser parser = new ScriptlyParser(tokens);
		return parser;
	}
}
