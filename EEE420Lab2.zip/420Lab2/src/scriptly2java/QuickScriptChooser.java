package scriptly2java;

public class QuickScriptChooser {

	/**
	 * Translates the TEST_FILE into an equivalent standalone Java program and 
	 * displays it on the console.
	 * 
	 * @author EEE/GEF420 instructors
	 * 
	 * @version 8 July 2016
	 *
	 */

	static final String TEST_FILE_DIR = "test files";
	static final String TEST_FILE = "Countdown.scriptly";
	
	public static void main(String[] args) throws Exception {
		String basedir = System.getProperty("user.dir");
		String sourceFilePath = basedir + "/" + TEST_FILE_DIR + "/" + TEST_FILE;
		String translation = Driver.translateFile(sourceFilePath);
		System.out.println(translation);
	}

}

