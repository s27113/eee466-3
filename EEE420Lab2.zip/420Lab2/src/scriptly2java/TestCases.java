package scriptly2java;

/**
 * REPLACE THIS COMMENT WITH YOUR OWN.
 * 
 * A few test cases have been provided. Students are required to design and implement 
 * the remainder, which must be sufficient to thoroughly test the translator. Requires
 * jUnit 4. 
 * 
 * Several utility functions have been provided to simplify writing test cases.
 * 
 * @author [your names here]
 * 
 * @version [completion date here]

 */
import static org.junit.Assert.assertEquals;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.junit.Test;

import scriptlygrammar.ScriptlyLexer;
import scriptlygrammar.ScriptlyParser;

public class TestCases {

	/** Translates the provided source as a Scriptly expression.
	    See the provided Scriptly grammar. */
	public static String expr(String source) {
		return translate(stringParser(source).expr());
	}

	/** Translates the provided source as a Scriptly statement. */
	public static String statement(String source) {
		return translate(stringParser(source).statement());
	}

	/** ... as a Scriptly statement block. */
	public static String block(String source) {
		return translate(stringParser(source).block());
	}

	/** ... as a Scriptly variable declaration. */
	public static String varDec(String source) {
		return translate(stringParser(source).varDec());
	}

	/** ... as a Scriptly variable declaration block. */
	public static String varBlock(String source) {
		return translate(stringParser(source).varBlock());
	}

	/** ... as a Scriptly function definition. */
	public static String funcDef(String source) {
		return translate(stringParser(source).funcDef());
	}

	/** ... as a Scriptly body element. */
	public static String body(String source) {
		return translate(stringParser(source).body());
	}

	/** ... as a Scriptly script. */
	public static String script(String source) {
		return translate(stringParser(source).script());
	}

	/** Performs the actual translation */
	public static String translate(ParseTree tree) {
		ParseTreeWalker walker = new ParseTreeWalker();
		Translator translator = new Translator();
		walker.walk(translator, tree);
		return translator.javaTranslations.get(tree);
	}
	
	/** Generates a Scriptly parser on the provided source string */
	public static ScriptlyParser stringParser(String source) {
		ANTLRInputStream input = new ANTLRInputStream(source);
		ScriptlyLexer lexer = new ScriptlyLexer(input);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		ScriptlyParser parser = new ScriptlyParser(tokens);
		return parser;
	}

	/** Replaces all contiguous white space with small dots; useful for testing 
	    the exact whitespace is not relevant. */
	public static String ws2dot(String str) {
		return str.replaceAll("\\s+", "\u00B7");
	}

	@Test
	public void literalExpressions() {
		assertEquals("0", expr("0"));
		assertEquals("123", expr("123"));
		assertEquals("true", expr("true"));
		assertEquals("false", expr("false"));
		assertEquals("\"ABC\"", expr("\"ABC\""));
	}

//	@Test
//	public void variableExpression() {
//	}
//
//	@Test
//	public void funcCallExpression() {
//	}
//
//	@Test
//	public void compareExpressions() {
//	}
//
//	@Test
//	public void addSubExpressions() {
//	}
//
//	@Test
//	public void mulDivExpressions() {
//	}
//
//	@Test
//	public void negExpressions() {
//	}
//
//	@Test
//	public void parensExpressions() {
//	}
//
//	/* ---- Statements ---- */
//
//	@Test
//	public void expressionStatements() {
//	}
//
//	@Test
//	public void returnStatement() {
//	}
//
//	@Test
//	public void printStatement() {
//	}
//
//	@Test
//	public void ifStatement() {
//	}
//
//	@Test
//	public void whileStatement() {
//	}
//
//	@Test
//	public void assignmentStatement() {
//	}
//
//	/* --- block --- */
//
//	@Test
//	public void blockTest() {
//	}
//
//	/* --- varDec --- */
//
//	@Test
//	public void varDecTest() {
//	}
//
//	/* ---- varBlock ---- */
//
//	@Test
//	public void varBlockTest() {
//	}
//
//	/* ---- body ---- */
//	@Test
//	public void bodyTest() {
//	}
//
//	/* ---- funcDef ---- */
//	@Test
//	public void funcDefTest() {
//	}
//
//	/* --- main --- */
//	@Test
//	public void mainTest() {
//	}
//
//	/* --- script --- */
//	@Test
//	public void scriptTest() {
//	}

}
