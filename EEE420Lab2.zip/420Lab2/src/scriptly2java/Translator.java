package scriptly2java;

import java.util.List;
import java.util.Map;

import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.stringtemplate.v4.ST;

import scriptlygrammar.ScriptlyBaseListener;
import scriptlygrammar.ScriptlyParser;
import util420.IOUtils;

/**
 * REPLACE THIS COMMENT WITH YOUR OWN.
 * 
 * A start point for translating a Scriptly source file into an equivalent stand
 * alone Java program. Students are required to complete.
 * 
 * Requires a correct generated Scriptly parser (Listener Pattern) in the
 * <code>scriptlygrammar</code> package, an appropriate set of templates in the
 * <code>templates</code> package, and the <code>util420.IOUtils</code> class.
 *
 * The antlr-4.5.3-complete.jar file must be added to the build path as an
 * external library.
 * 
 * 
 * @author [your names here]
 * 
 * @version [completion date here]
 *
 */
public class Translator extends ScriptlyBaseListener {

	public static final String[] templateNames = { "class", "main", "functionDecl", "while" };

	private Map<String, String> templates;
	protected ParseTreeProperty<String> javaTranslations;

	public Translator() {
		templates = IOUtils.loadTemplates(templateNames);
		javaTranslations = new ParseTreeProperty<String>();
	}

	public void setJava(ParseTree node, String java) {
		javaTranslations.put(node, java);
	}

	public String getJava(ParseTree node) {
		return javaTranslations.get(node);
	}

	@Override
	public void exitScript(ScriptlyParser.ScriptContext ctx) {
		ST classTemplate = new ST(templates.get("class"));
		String result = "";
		for (ScriptlyParser.FuncDefContext code : ctx.funcDef())
			result = result + getJava(code) + "\n";
		result = result + getJava(ctx.main());
		classTemplate.add("mainBody", result);
		setJava(ctx, classTemplate.render());
	}

	@Override
	public void exitFuncDef(ScriptlyParser.FuncDefContext ctx) {
		ST funcDefTemplate = new ST(templates.get("functionDecl"));
		String arguments = "";
		List<ScriptlyParser.VarNameDefContext> argsList = ctx.varNameDef();
		if (ctx.TYPE() == null)
			funcDefTemplate.add("returnType", "void");
		else if(ctx.TYPE().getText().equals("Int"))
			funcDefTemplate.add("returnType", "int");
		else if(ctx.TYPE().getText().equals("Bool"))
			funcDefTemplate.add("returnType", "boolean");
		else
			funcDefTemplate.add("returnType", ctx.TYPE().getText());
		funcDefTemplate.add("functionName", ctx.ID().getText());
		for (int i = 0; i < argsList.size(); i++) {
			if (i == argsList.size() - 1)
				arguments += getJava(argsList.get(i));
			else
				arguments += getJava(argsList.get(i)) + ", ";
		}
		funcDefTemplate.add("arguments", arguments);
		funcDefTemplate.add("functionCode", getJava(ctx.body()));
		setJava(ctx, funcDefTemplate.render());
	}

	@Override
	public void exitMain(ScriptlyParser.MainContext ctx) {
		ST mainTemplate = new ST(templates.get("main"));
		mainTemplate.add("mainCode", getJava(ctx.body()));
		setJava(ctx, mainTemplate.render());
	}

	@Override
	public void exitBody(ScriptlyParser.BodyContext ctx) {
		setJava(ctx, getJava(ctx.varBlock()) + getJava(ctx.block()));
	}

	@Override
	public void exitVarDec(ScriptlyParser.VarDecContext ctx) {
		String result = getJava(ctx.varNameDef());
		if (ctx.getChildCount() == 1)
			setJava(ctx, result + ";");
		else
			setJava(ctx, result + " = " + getJava(ctx.expr()) + ";");
	}

	@Override
	public void exitVarNameDef(ScriptlyParser.VarNameDefContext ctx) {
		String result = "";
		switch (ctx.TYPE().getText()) {
		case "Int":
			result += "int ";
			break;
		case "Bool":
			result += "boolean ";
			break;
		case "String":
			result += "String ";
			break;
		}
		result += ctx.ID().getText();
		setJava(ctx, result);
	}

	@Override
	public void exitVarBlock(ScriptlyParser.VarBlockContext ctx) {
		String result = "";
		for (ScriptlyParser.VarDecContext statement : ctx.varDec()) {
			result += getJava(statement) + "\n";
		}
		setJava(ctx, result);
	}

	@Override
	public void exitBlock(ScriptlyParser.BlockContext ctx) {
		String result = "";
		List<ScriptlyParser.StatementContext> statements = ctx.statement();
		for (int i = 0; i < statements.size(); i++) {
			if (i != statements.size() - 1)
				result += getJava(statements.get(i)) + "\n";
			else
				result += getJava(statements.get(i));
		}
		setJava(ctx, result);
	}

	@Override
	public void exitAssignment(ScriptlyParser.AssignmentContext ctx) {
		setJava(ctx, ctx.ID().getText() + " = " + getJava(ctx.expr()) + ";");
	}

	@Override
	public void exitWhile(ScriptlyParser.WhileContext ctx) {
		ST whileTemplate = new ST(templates.get("while"));
		whileTemplate.add("condition", getJava(ctx.expr()));
		whileTemplate.add("repeatText", getJava(ctx.block()));
		setJava(ctx, whileTemplate.render());
	}

	@Override
	public void exitIf(ScriptlyParser.IfContext ctx) {
		List<ScriptlyParser.BlockContext> blocks = ctx.block();
		String result = "if (";
		result += getJava(ctx.expr()) + ") {\n";
		result += getJava(blocks.get(0));
		result += "\n} ";
		if (blocks.size() == 2) {
			result += "else {\n" + getJava(blocks.get(1)) + "\n}";
		}
		setJava(ctx, result);
	}

	@Override
	public void exitPrint(ScriptlyParser.PrintContext ctx) {
		setJava(ctx, "System.out.print(" + getJava(ctx.expr()) + ");");
	}

	@Override
	public void exitReturn(ScriptlyParser.ReturnContext ctx) {
		if (ctx.getChildCount() == 0)
			setJava(ctx, "return;");
		else
			setJava(ctx, "return " + getJava(ctx.expr()) + ";");
	}

	@Override
	public void exitExprStatement(ScriptlyParser.ExprStatementContext ctx) {
		setJava(ctx, getJava(ctx.expr()) + ";");
	}

	@Override
	public void exitParens(ScriptlyParser.ParensContext ctx) {
		setJava(ctx, "(" + getJava(ctx.expr()) + ")");
	}

	@Override
	public void exitNeg(ScriptlyParser.NegContext ctx) {
		setJava(ctx, ctx.op.getText() + getJava(ctx.expr()));
	}

	@Override
	public void exitMulDiv(ScriptlyParser.MulDivContext ctx) {
		setJava(ctx, getJava(ctx.expr(0)) + " " + ctx.op.getText() + " " + getJava(ctx.expr(1)));
	}

	@Override
	public void exitAddSub(ScriptlyParser.AddSubContext ctx) {
		setJava(ctx, getJava(ctx.expr(0)) + " " + ctx.op.getText() + " " + getJava(ctx.expr(1)));
	}

	@Override
	public void exitCompare(ScriptlyParser.CompareContext ctx) {
		setJava(ctx, getJava(ctx.expr(0)) + " " + ctx.op.getText() + " " + getJava(ctx.expr(1)));
	}

	@Override
	public void exitFuncCall(ScriptlyParser.FuncCallContext ctx) {
		String result = ctx.ID().getText() + "(";
		List<ScriptlyParser.ExprContext> arguments = ctx.expr();
		for (int i = 0; i < arguments.size(); i++) {
			if (i == arguments.size() - 1)
				result += getJava(arguments.get(i));
			else
				result += getJava(arguments.get(i)) + ", ";
		}
		result += ")";
		setJava(ctx, result);
	}

	@Override
	public void exitVariable(ScriptlyParser.VariableContext ctx) {
		setJava(ctx, ctx.getText());
	}

	@Override
	public void exitString(ScriptlyParser.StringContext ctx) {
		setJava(ctx, ctx.getText());
	}

	@Override
	public void exitInt(ScriptlyParser.IntContext ctx) {
		setJava(ctx, ctx.getText());
	}

	@Override
	public void exitBool(ScriptlyParser.BoolContext ctx) {
		setJava(ctx, ctx.getText());
	}

}
