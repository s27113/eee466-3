package scriptly2java;

import util420.IOUtils;

public class WindowScriptChooser {

	/**
	 * Allows the user to choose a Scriptly source file and translates it into
	 * an equivalent stand alone Java program. The Scriptly source file name
	 * must end in <code>.scriptly</code> The resulting Java file will be
	 * written to a package called <code>generated</code> in the same
	 * <code>src</code> folder that this file is contained in.
	 * 
	 * @author EEE/GEF420 instructors
	 * 
	 * @version 7 July 2016
	 *
	 */

	public static void main(String[] args) throws Exception {
		String sourceFilePath = IOUtils.chooseSourceFile("Scriptly source", "scriptly");
		String translation = Driver.translateFile(sourceFilePath);
		String basename = IOUtils.baseName(sourceFilePath);
		IOUtils.saveGeneratedFile(translation, basename + ".java");
		System.out.println(translation);
	}

}
