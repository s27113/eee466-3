// Generated from Scriptly.g4 by ANTLR 4.5.3

package scriptlygrammar;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ScriptlyParser}.
 */
public interface ScriptlyListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#script}.
	 * @param ctx the parse tree
	 */
	void enterScript(ScriptlyParser.ScriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#script}.
	 * @param ctx the parse tree
	 */
	void exitScript(ScriptlyParser.ScriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#funcDef}.
	 * @param ctx the parse tree
	 */
	void enterFuncDef(ScriptlyParser.FuncDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#funcDef}.
	 * @param ctx the parse tree
	 */
	void exitFuncDef(ScriptlyParser.FuncDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#main}.
	 * @param ctx the parse tree
	 */
	void enterMain(ScriptlyParser.MainContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#main}.
	 * @param ctx the parse tree
	 */
	void exitMain(ScriptlyParser.MainContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(ScriptlyParser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(ScriptlyParser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#varDec}.
	 * @param ctx the parse tree
	 */
	void enterVarDec(ScriptlyParser.VarDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#varDec}.
	 * @param ctx the parse tree
	 */
	void exitVarDec(ScriptlyParser.VarDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#varNameDef}.
	 * @param ctx the parse tree
	 */
	void enterVarNameDef(ScriptlyParser.VarNameDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#varNameDef}.
	 * @param ctx the parse tree
	 */
	void exitVarNameDef(ScriptlyParser.VarNameDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#varBlock}.
	 * @param ctx the parse tree
	 */
	void enterVarBlock(ScriptlyParser.VarBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#varBlock}.
	 * @param ctx the parse tree
	 */
	void exitVarBlock(ScriptlyParser.VarBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link ScriptlyParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(ScriptlyParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link ScriptlyParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(ScriptlyParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignment}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(ScriptlyParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignment}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(ScriptlyParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code while}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterWhile(ScriptlyParser.WhileContext ctx);
	/**
	 * Exit a parse tree produced by the {@code while}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitWhile(ScriptlyParser.WhileContext ctx);
	/**
	 * Enter a parse tree produced by the {@code if}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterIf(ScriptlyParser.IfContext ctx);
	/**
	 * Exit a parse tree produced by the {@code if}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitIf(ScriptlyParser.IfContext ctx);
	/**
	 * Enter a parse tree produced by the {@code print}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterPrint(ScriptlyParser.PrintContext ctx);
	/**
	 * Exit a parse tree produced by the {@code print}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitPrint(ScriptlyParser.PrintContext ctx);
	/**
	 * Enter a parse tree produced by the {@code return}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterReturn(ScriptlyParser.ReturnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code return}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitReturn(ScriptlyParser.ReturnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprStatement}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterExprStatement(ScriptlyParser.ExprStatementContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprStatement}
	 * labeled alternative in {@link ScriptlyParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitExprStatement(ScriptlyParser.ExprStatementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code neg}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNeg(ScriptlyParser.NegContext ctx);
	/**
	 * Exit a parse tree produced by the {@code neg}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNeg(ScriptlyParser.NegContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parens}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParens(ScriptlyParser.ParensContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parens}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParens(ScriptlyParser.ParensContext ctx);
	/**
	 * Enter a parse tree produced by the {@code compare}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterCompare(ScriptlyParser.CompareContext ctx);
	/**
	 * Exit a parse tree produced by the {@code compare}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitCompare(ScriptlyParser.CompareContext ctx);
	/**
	 * Enter a parse tree produced by the {@code string}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterString(ScriptlyParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code string}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitString(ScriptlyParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code bool}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBool(ScriptlyParser.BoolContext ctx);
	/**
	 * Exit a parse tree produced by the {@code bool}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBool(ScriptlyParser.BoolContext ctx);
	/**
	 * Enter a parse tree produced by the {@code variable}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVariable(ScriptlyParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code variable}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVariable(ScriptlyParser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code addSub}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAddSub(ScriptlyParser.AddSubContext ctx);
	/**
	 * Exit a parse tree produced by the {@code addSub}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAddSub(ScriptlyParser.AddSubContext ctx);
	/**
	 * Enter a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFuncCall(ScriptlyParser.FuncCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFuncCall(ScriptlyParser.FuncCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code int}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterInt(ScriptlyParser.IntContext ctx);
	/**
	 * Exit a parse tree produced by the {@code int}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitInt(ScriptlyParser.IntContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mulDiv}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMulDiv(ScriptlyParser.MulDivContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mulDiv}
	 * labeled alternative in {@link ScriptlyParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMulDiv(ScriptlyParser.MulDivContext ctx);
}