package util420;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * Utility functions for handling input and output, in the context of ANTLR
 * parser construction.
 * 
 * @author EEE/GEF420 Instructors
 * 
 * @version 7 July 2016
 *
 */
public class IOUtils {

	/**
	 * Allows user to choose a source file for translation, using the system
	 * file chooser, starting from the current working directory.
	 * 
	 * @param type
	 *            A meaningful name for the type of file to open
	 * @param extension
	 *            The expected extension for that type of file
	 * @return The absolute path reference for the chosen file
	 */
	public static String chooseSourceFile(String type, String extension) {
		JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
		FileNameExtensionFilter filter = new FileNameExtensionFilter(type,
				extension);
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(null);
		if (returnVal != JFileChooser.APPROVE_OPTION) {
			System.out.println("No source file chosen; shutting down.");
			System.exit(-1);
		}
		return chooser.getSelectedFile().getAbsolutePath();
	}

	/**
	 * Saves <code>contents</code> to a file with the given <code>name</code> in
	 * a subdirectory <code>src/generated</code> of the user's current working
	 * directory. Will overwrite existing files. If the directory does not
	 * exist, attempts to create it. On error, provides a descriptive message
	 * and exits.
	 * 
	 * @param contents
	 *            The desired contents of the file to be saved
	 * @param name
	 *            The desired file name
	 */
	public static void saveGeneratedFile(String contents, String name) {
		Path generatedFileDirectory = Paths.get(System.getProperty("user.dir"),
				"src", "generated");
		if (!Files.isDirectory(generatedFileDirectory)) {
			try {
				Files.createDirectory(generatedFileDirectory);
			} catch (IOException ioex) {
				System.err.println("Directory for generated files \n   "
						+ generatedFileDirectory);
				System.err.println("doesn't exist and couldn't be created");
				System.exit(-1);
			}
		}
		Path savePath = Paths.get(generatedFileDirectory.toString(), name);
		try {
			writeUTF8File(savePath, contents);
		} catch (IOException e) {
			System.err.println("Unable to save generated file at " + savePath
					+ "\n... shutting down");
			System.exit(-1);
		}
	}

	/**
	 * Reads a file, assumed to be in UTF-8 encoding.
	 * 
	 * @param path
	 *            Pathname of the file to be read
	 * @return The contents of the file, as read
	 * @throws IOException
	 *             If the file cannot be read (e.g., doesn't exist, etc)
	 */
	public static String readUTF8File(Path path) {
		try {
			byte[] encoded = Files.readAllBytes(path);
			String decoded = new String(encoded, StandardCharsets.UTF_8);
			return decoded;
		} catch (IOException e) {
			System.err.println("unable to read file at " + path);
			return "ERROR: file at " + path + " could not be read";
		}
	}

	/**
	 * Writes a file in UTF-8 encoding. Will overwrite existing files.
	 * 
	 * @param path
	 *            The path at which to write
	 * @param contents
	 *            The contents of the file to write
	 * @throws IOException
	 *             If the file cannot be written (e.g., no such directory,
	 *             permissions problem, etc)
	 */
	public static void writeUTF8File(Path path, String contents)
			throws IOException {
		byte[] encoded = contents.getBytes("UTF-8");
		Files.write(path, encoded);
	}

	/**
	 * Loads the given templates using the <code>readTemplate</code> function.
	 * 
	 * @see #readTemplate
	 * @param names
	 *            The names of the templates to be read, not including the file
	 *            extension, which is assumed to be <code>.txt</code> (so, to
	 *            read <code>myTemplate.txt</code> ask for
	 *            <code>myTemplate</code>)
	 * @return A Map where the keys are the template names and the values are
	 *         the contents of the corresponding templates.
	 * @throws URISyntaxException
	 *             from <code>readTemplate</code>
	 * @throws IOException
	 *             from <code>readTemplate</code>
	 */
	public static Map<String, String> loadTemplates(String[] names) {
		Map<String, String> templates = new HashMap<String, String>();
		for (String name : names) {
			templates.put(name, readTemplate(name + ".txt"));
		}
		return templates;
	}

	/**
	 * Reads a single template, which is assumed to be in a
	 * <code>templates</code> directory at the root of the
	 * 
	 * @param name
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public static String readTemplate(String name) {
		URL url = IOUtils.class.getResource("/templates/" + name);
		try {
			URI uri = url.toURI();
			Path path = Paths.get(uri);
			return readUTF8File(path);
		} catch (URISyntaxException e) {
			System.err.println("template path " + url + " is not valid");
			return "ERROR: template path " + url + " not valid; template not read";
		}
	}

	/**
	 * Computes the base filename for the given path.
	 * 
	 * @param filePath
	 *            An absolute or relative path name
	 * @return The part of the filename before the first period. E.g., for the
	 *         pathname
	 *         <code>/A/Really/long/pathname/with/a-filename.whatever.text</code>
	 *         returns <code>a-filename</code>.
	 */
	public static String baseName(String filePath) {
		return (new File(filePath)).getName().split("\\.")[0];
	}

}
