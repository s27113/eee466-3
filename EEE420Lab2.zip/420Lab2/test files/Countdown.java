package generated;

public class Countdown {

	/* --- Built ins --- */
	static int count(String str) {
		return str.length();
	}

	static String substring(String str, int start, int length) {
		return str.substring(start, start+length);
	}

	/* --- Generated --- */
	static void countdown(int from, String message) {
		int current = from;
		while (0 < current) {
			current = displayAndDecrementCount(current);
		}
		System.out.print(message + "\n");
	}

	static int displayAndDecrementCount(int c) {
		System.out.print(c);
		System.out.print("\n");
		c = c - 1;
		if (c == 3) {
			System.out.print("Get ready!\n");
		}
		return c;
	}


	/* --- Main --- */
	public static void main(String[] args) {
	    String announce = "Liftoff";
	    countdown(10, announce);
	}
}
